package Actors;

import java.awt.*;

public class Enemy extends AbstractActor
{
    // TODO:

    @Override
    public boolean isDead()
    {
        // TODO:
    }

    @Override
    public void update(float deltaT, Graphics2D g)
    {
        // TODO: or delete

    }
}
