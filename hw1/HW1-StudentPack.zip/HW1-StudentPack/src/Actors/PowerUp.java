package Actors;

import java.awt.*;

public class PowerUp extends AbstractActor
{
    // TODO:

    @Override
    public void update(float deltaT, Graphics2D g)
    {
        // TODO or delete
    }

    @Override
    public boolean isDead()
    {
        // TODO:
    }


}
