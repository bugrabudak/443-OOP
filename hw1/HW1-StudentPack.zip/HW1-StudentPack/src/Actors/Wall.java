package Actors;

import java.awt.*;

public class Wall extends AbstractActor
{
    @Override
    public void update(float deltaT, Graphics2D g)
    {
        // TODO: or delete
    }

    @Override
    public boolean isDead()
    {
        // TODO:
    }
}
