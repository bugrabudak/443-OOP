package Components;

public abstract class AbstractPatrolStrategy implements IRealTimeComponent
{
    // TODO:
    @Override
    public void update(float deltaT)
    {
        // TODO:
    }
}
