package Components;

public interface ICollisionListener
{
    // You can change the interface here (add arguments to the function or
    // change the name etc.)
    public void aCollisionIsHappened();
}
