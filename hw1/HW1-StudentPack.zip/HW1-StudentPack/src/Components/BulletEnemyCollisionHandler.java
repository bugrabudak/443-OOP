package Components;

public class BulletEnemyCollisionHandler implements IRealTimeComponent
{
    // TODO:
    @Override
    public void update(float deltaT)
    {
        // TODO:
    }
}
