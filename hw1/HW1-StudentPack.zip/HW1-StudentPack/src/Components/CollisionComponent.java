package Components;

public class CollisionComponent implements IRealTimeComponent
{
    // TODO:
    @Override
    public void update(float deltaT)
    {
        // TODO:
    }


}
